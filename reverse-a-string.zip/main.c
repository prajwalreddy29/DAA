/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
int main()
{
   char s[100], r[100];
   int b, e, count=0;
   scanf("%s", s);
   while(s[count]!='\0')
       count++;
   e = count-1;
   for(b=0;b<count;b++)
   {
       r[b]=s[e];
       e--;
   }
   r[b]='\0';
   printf("%s\n", r);
   return 0;
}