#include<stdio.h>
int main(){
    int arr[100],i,n,target,flag=0;
    printf("Enter the number of elements in array: ");
    scanf("%d",&n);
    printf("Enter numbers of array: ");
    for(i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    printf("Enter the number to be searched: ");
    scanf("%d",&target);
    for(i=0;i<n;i++){
        if(arr[i]==target){
            flag=1;
            printf("Element found in array");
        }
    }
    if(flag==0){
        printf("Element not found in array");
    }
    return 0;
}
